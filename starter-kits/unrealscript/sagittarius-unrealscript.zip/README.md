# Sagittarius - UnrealScript Starter Kit

## Installation

Visit [here](http://willyg302.github.io/Sagittarius/unrealscript) for installation instructions.
