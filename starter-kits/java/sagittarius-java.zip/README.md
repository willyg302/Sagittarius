# Sagittarius - Java Starter Kit

## Installation

Visit [here](http://willyg302.github.io/Sagittarius/java) for installation instructions.
