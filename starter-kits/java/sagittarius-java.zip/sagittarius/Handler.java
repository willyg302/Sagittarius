/**
 * Sagittarius - Java Starter Kit
 * Copyright WillyG Productions
 * @Authors: William Gaul
 */
package sagittarius;

public abstract class Handler {
    public abstract void invoke();
}
