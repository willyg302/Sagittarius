# Sagittarius - JavaScript Starter Kit

## Installation

Visit [here](http://willyg302.github.io/Sagittarius/starter-kits/javascript) for installation instructions.
