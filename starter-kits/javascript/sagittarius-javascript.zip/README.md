# Sagittarius - JavaScript Starter Kit

## Installation

Visit [here](http://willyg302.github.io/Sagittarius/javascript) for installation instructions.
